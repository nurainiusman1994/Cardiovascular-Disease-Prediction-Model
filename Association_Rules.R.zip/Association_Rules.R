install.packages("arules")
install.packages("arulesViz")

library("arules")
library(arulesViz)

### On inbuilt Data set #####
data("Groceries")
?Groceries

summary(Groceries)
inspect(Groceries[1:10])

rules <- apriori(Groceries,parameter = list(support = 0.008,confidence = 0.08,minlen=2))
inspect(rules[1:5])

windows()
plot(rules,method = "scatterplot")
plot(rules,method = "grouped")
plot(rules,method = "graph")

rules <- sort(rules,by="lift")

inspect(rules[1:5])
